
import { sum } from './sum.js';

// Exemplo simples: imprime a soma só para termos um ponto de entrada
if (process.env.NODE_ENV !== 'test') {
  console.log('Soma(2, 3) =', sum(2, 3));
}

export function hello(name = 'DevOps') {
  return `Hello, ${name}!`;
}
