
import { sum } from '../src/sum.js';
import { hello } from '../src/index.js';

test('sum adds numbers correctly', () => {
  expect(sum(2, 3)).toBe(5);
  expect(sum(-1, 1)).toBe(0);
});

test('hello returns greeting', () => {
  expect(hello('Lessandro')).toBe('Hello, Lessandro!');
});
