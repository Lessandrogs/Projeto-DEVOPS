
# Plano do Projeto — Fase 1 (Configuração e Automação Inicial)

## 1. Descrição do Projeto
**Nome do projeto:** _[preencha aqui]_  
**Contexto/Problema:** _[o que o projeto resolve?]_  
**Escopo:** _[aplicação, serviços, pipeline, IaC]_

## 2. Objetivos (SMART)
- **Específico:** _[ex.: ter pipeline CI rodando testes a cada PR]_  
- **Mensurável:** _[ex.: 100% dos PRs disparam CI]_  
- **Atingível:** _[ex.: usando GitHub Actions/Jest]_  
- **Relevante:** _[ex.: qualidade + feedback rápido]_  
- **Temporal:** _[ex.: até DD/MM/AAAA]_

## 3. Requisitos
### 3.1 Funcionais
- Rodar testes automatizados a cada push/PR na branch `main`.
- Publicar artefatos de teste (relatório Jest) como saída do pipeline.

### 3.2 Não Funcionais
- Automação com GitHub Actions.
- Código versionado no GitHub.
- Infra como Código com Terraform.
- Padrões de qualidade (execução de testes e `npm ci`).

## 4. Plano de Integração Contínua (CI)
- **Triggers:** `push` e `pull_request` para `main`.
- **Jobs/Estágios:** checkout → setup Node → instalação → testes.
- **Ferramentas:** GitHub Actions, Node 20, Jest.
- **Critérios de sucesso:** testes passam (exit code 0).

## 5. Especificação de Infraestrutura (IaC)
- **Cloud:** AWS
- **Recursos:** EC2 `t2.micro` (free tier), Security Group com portas 22 (SSH) e 3000 (app).
- **Rede:** VPC padrão.
- **AMI:** Amazon Linux 2023 (x86_64), mais recente.
- **Gerenciamento:** Terraform (módulo `aws`), estado local.
- **Variáveis:** `region`, `instance_type`, `key_name` (opcional para SSH).
- **Custos:** possíveis custos se aplicar. Rodar apenas `plan` para ver mudanças.

## 6. Riscos e Mitigações
- **Credenciais AWS inválidas:** usar `aws configure` e variáveis de ambiente.  
- **Custos inesperados:** usar apenas `plan` ou destruir (`terraform destroy`) após testes.  
- **Falhas no CI:** revisar logs na aba Actions.

## 7. Evidências
- **Link do repositório GitHub:** _[cole aqui]_  
- **Prints do pipeline (Actions):** _[insira aqui]_  
- **Saída do `terraform plan` (opcional):** _[insira aqui]_

---

> **Observação:** Este documento segue o pedido dos professores e deve ser incluído no repositório. Lembre de anexar prints e o link do repo.
